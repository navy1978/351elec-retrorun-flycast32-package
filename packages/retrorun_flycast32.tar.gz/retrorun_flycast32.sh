#!/bin/bash
# rm /dev/input/by-path/platform-odroidgo2-joypad-event-joystick
# touch /dev/input/by-path/platform-odroidgo2-joypad-event-joystick 
./apps/rg351p-js2xbox --silent -t oga_joypad &
sleep 1
ln -s /dev/input/event3 /dev/input/by-path/platform-odroidgo2-joypad-event-joystick
chmod 777 /dev/input/by-path/platform-odroidgo2-joypad-event-joystick
LD_LIBRARY_PATH=/usr/lib32:./lib:./lib/retrorun ./apps/retrorun32 --triggers -n -s /roms/ivan_test/logs/ -d /roms/bios ./core/flycast32_rumble_libretro.so  "$1"
kill $(pidof rg351p-js2xbox)
rm /dev/input/by-path/platform-odroidgo2-joypad-event-joystick

